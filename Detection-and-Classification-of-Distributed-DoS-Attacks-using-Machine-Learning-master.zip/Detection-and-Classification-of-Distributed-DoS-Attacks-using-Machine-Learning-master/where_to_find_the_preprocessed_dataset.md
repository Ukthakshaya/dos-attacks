Orinal dataset can be found on Canadian Institute for Cybersecurity website:
https://www.unb.ca/cic/datasets/ddos-2019.html

~~The datasets used in the pre-processing IPython Notebook (DDOS_dataProcessing.ipynb) can be downloaded from the following link:~~
~~https://drive.google.com/drive/folders/1BBCAAL7I4xKwRQJ8Joziqi28PccBQGOi?usp=sharing~~

Update (Jan, 2022):

The datasets are in two parts and can be found here:
https://drive.google.com/drive/folders/1BBCAAL7I4xKwRQJ8Joziqi28PccBQGOi?usp=sharing
https://drive.google.com/drive/folders/1-0nrb9K4mwgpeLqRr7jrsTYVockLQm2J?usp=sharing
There has been some changes in the way this data was stored during the project and necessary changes will be required in the ipnb files to read the datasets correctly. Please note that this project is no longer maintained so I won't be updating the ipython notebooks 
